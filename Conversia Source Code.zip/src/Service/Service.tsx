import axios, { AxiosError } from "axios";
import Config from "../Global/Global";
//axios.defaults.baseURL = "http://35.154.213.141/conversia/";
axios.defaults.baseURL = "https://www.conversiahelpline.com/api/";
// axios.defaults.headers = {'Access-Control-Allow-Origin': '*'}
// axios.defaults.baseURL = "http://localhost:8083/";
export default class Service {

    // Login 
    async login(email: any, password: any) {
        const loginResponse = await axios({
            url: "authenticate",
            method: "POST",
            data: {
                "email_id": email,
                "password": password
            }
        })
        this.setDetails(loginResponse.data);
        return loginResponse;
    }

    //set access token globally
    setDetails(details: any) {
        sessionStorage.setItem("accessToken", details.token);
        sessionStorage.setItem("userName", details.firstname);
        sessionStorage.setItem("userType", details.usertype);
    }

    //get meeting details
    async getMeetingDetails() {
        const getMeetingDetailsResponse = await axios({
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken")
            },
            url: "meetings",
            method: "GET"
        })
        return getMeetingDetailsResponse;
    }

    //create meeting details
    async createMeeting(data: any) {
        try {
            const createMeetingResponse = await axios({
                headers: {
                    'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken")
                },
                url: "meetings",
                method: "POST",
                data: {
                    seeker: {
                        "user_id": data.user_id,
                        "firstname": data.firstname,
                        "lastname": data.lastname,
                        "email_id": data.email_id,
                        "phone": data.phone,
                        "hospital": data.hospital,
                        "city": data.city,
                        "specialty": data.specialty,
                        "user_type": 1,
                        "password": data.confirmpwd
                    },
                    "expert_id": data.doctorSelect,
                    "meeting_date": data.pickdate + "T" + data.picktime
                }
            })
            return createMeetingResponse;
        }
        catch (error) {
            const err = error as AxiosError;
            if (err.response) {
                return err.response;
            }
        }
    }


    async getMeetingToken(meetingSid: any) {
        const result = await axios({
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken")
            },
            url: "twilio/token/" + meetingSid,
            method: "GET",
        });
        return result;
    }

    // fileupload
    async fileUpload(files: any, meetingId: any) {
        const result = await axios({
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken"),
                'content-type': 'multipart/form-data',
            },
            url: "meetings/" + meetingId + "/files/upload",
            method: "POST",
            data: files,
        });
        return result;
    }

    // get files
    async getFiles(meetingId: any) {
        const result = await axios({
            url: "meetings/" + meetingId + "/files",
            method: "GET",
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken"),
            }
        });
        return result.data;
    }


    // FileDownload
    async fileDownload(meetingId: any, fileId: any) {
        const result = await axios({
            url: "meetings/" + meetingId + "/files/" + fileId,
            method: "GET",
            responseType: 'arraybuffer',
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken"),
            }
        });
        return result.data;
    }

    //reject Meeting
    async rejectMeeting(meetingId: any, res: any) {
        const result = await axios({
            method: "PUT",
            url: "meetings/" + meetingId + "?reason=" + res,
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken"),
                'Accept': '*/*'
            },

        });
        return result.status;
    }

    // followUpMeeting
    async followUpMeeting(meetingDetails: any) {
        const result = await axios({
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken")
            },
            url: "meetings",
            method: "POST",
            data: {
                "seeker": {
                    "user_id": meetingDetails.user_id
                },
                "expert_id": meetingDetails.expert_id,
                "meeting_date": meetingDetails.meeting_date,
                "follow_up_on": meetingDetails.follow_up_on
            }
        });
        return result;
    }


    async searchUser(userMailId:any){
        const result = await axios({
            headers: {
                'Authorization': 'Bearer ' + sessionStorage.getItem("accessToken")
            },
            url: "user",
            method: "POST",
            params:{emailId:userMailId}
        });
        return result;
    }
}