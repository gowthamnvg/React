// !-- telecaller login form validation



$(document).ready(function() {

    $(".view_reason_btn").click(function() {
        $(this).parent().parent().parent().find(".cardRequest").toggleClass("ri_active");
        $(this).parent().parent().parent().find(".cardReject_info").toggleClass("reasonUpdated");
    });




    $(".btn_reject").click(function() {
        $(this).toggleClass("btn_disabled");
        $(this).parent().parent().parent().parent().parent().find(".cardRequest").toggleClass("fi_active");
        $(this).parent().parent().parent().parent().parent().find(".cardReject_Input_wrapper").addClass("inputSecEnabled");
    });

});



$('#teleLoginForm').validate({
    rules: {
        tele_Email: {
            required: true,
            email: true
        },
        tele_Password: {
            required: true
        }

    },
    messages: {
        tele_Email: {
            required: "please Enter Email",
            email: "please Enter valid Email"
        },
        tele_Password: {
            required: "please Enter Password"
        }
    },
    errorPlacement: function(error, element) {
        error.insertAfter($(element));

    }
})

$('#TeleLogin').click(function() {
    $('#teleLoginForm').valid();
});



// seeker
$('#seekerLoginForm').validate({
    rules: {
        seeker_Email: {
            required: true,
            email: true
        },
        seeker_Password: {
            required: true
        }

    },
    messages: {
        seeker_Email: {
            required: "please Enter Email",
            email: "please Enter valid Email"
        },
        seeker_Password: {
            required: "please Enter Password"
        }
    },
    errorPlacement: function(error, element) {
        error.insertAfter($(element));

    }
})

$('#seekerLogin').click(function() {
    $('#seekerLoginForm').valid();
})



// panel expert
$('#panelExpertLoginForm').validate({
    rules: {
        panelExpert_Email: {
            required: true,
            email: true
        },
        panelExpert_Password: {
            required: true
        }

    },
    messages: {
        panelExpert_Email: {
            required: "please Enter Email",
            email: "please Enter valid Email"
        },
        panelExpert_Password: {
            required: "please Enter Password"
        }
    },
    errorPlacement: function(error, element) {
        error.insertAfter($(element));

    }
})

$('#panelExpertLogin').click(function() {
    $('#panelExpertLoginForm').valid();
})




// for password validation
var myInput = document.getElementById("createPassword");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");
var passStatus = false;

function onfocusInput() {
    document.getElementById("validationMsgDiv").style.display = "block";
}





// When the user starts to type something inside the password field

function onkeyupInput() {
    // Validate length
    if (myInput.value.length >= 8) {
        length.classList.remove("valInfoTx");
        length.classList.remove("invalid");
        length.classList.add("valid");
    } else {
        length.classList.remove("valid");
        length.classList.add("invalid");
    }




    // Validate capital letters
    var upperCaseLetters = /[A-Z]/g;
    if (myInput.value.match(upperCaseLetters)) {
        capital.classList.remove("valInfoTx");
        capital.classList.remove("invalid");
        capital.classList.add("valid");
    } else {
        capital.classList.remove("valid");
        capital.classList.add("invalid");
    }

    // Validate numbers
    var numbers = /[0-9]/g;
    if (myInput.value.match(numbers)) {
        number.classList.remove("valInfoTx");
        number.classList.remove("invalid");
        number.classList.add("valid");
    } else {
        number.classList.remove("valid");
        number.classList.add("invalid");
    }


    if (myInput.value.length >= 8 && myInput.value.length <= 15 && myInput.value.match(upperCaseLetters) && myInput.value.match(numbers)) {

        document.getElementById("validationMsgDiv").style.display = "none";

    } else {
        document.getElementById("validationMsgDiv").style.display = "block";
    }

}


// new request first form varlidation
$('#RequestFormOne').validate({
    rules: {
        fname: {
            required: true
        },
        Lname: {
            required: true
        },
        Remail_id: {
            required: true,
            email: true
        },
        phoneNumber: {
            required: true
        },
        createpwd: {
            required: true
        },
        confirmpwd: {
            required: true,
            equalTo: "#createPassword"
        },
        hospital: {
            required: true
        },
        city: {
            required: true
        },
        specility: {
            required: true
        },
        file: {
            required: true
        }
    },
    messages: {
        fname: {
            required: "please Enter First Name"
        },
        Lname: {
            filerequired: "please Enter Last Name"
        },
        Remail_id: {
            required: "please Enter Email",
            email: "please Enter Valid Email"
        },
        phoneNumber: {
            required: "please Enter Phonenumber"
        },
        createpwd: {
            required: "please Enter Valid Password"
        },
        confirmpwd: {
            required: "please Enter Password",
            equalTo: "please enter same password"

        },
        hospital: {
            required: "please Enter hospital name"
        },
        city: {
            required: "please Enter cityname"
        },
        specility: {
            required: "please select specility"
        },
        file: {
            required: "please choose files"
        }
    },
    errorPlacement: function(error, element) {
        if (element.attr("type") == "file") {
            error.insertAfter($(element).parent(".browseWrap"));
        } else {
            error.insertAfter($(element));
        }

    }
})

$('#formFirstSubmit').click(function(event) {
    event.preventDefault();
    var valid = $('#RequestFormOne').valid();
    // $('[required]').each(function() {
    //     if ($(this).is(':invalid') || !$(this).val()) valid = false;
    // })
    if (valid) {
        $('.indicatorFirst').removeClass('active');
        $('.indicatorSecond').addClass('active');
        $('.requestFirstForm').hide();
        $('.requestSecondForm').show();
        $('.nextBtn').hide();
        $('.submitBtn').show();
    }
})


$('#RequestFormTwo').validate({
    rules: {
        doctorSelect: {
            required: true
        },
        pickdate: {
            required: true
        },
        picktime: {
            required: true
        }
    },
    messages: {
        doctorSelect: {
            required: "Please Select Doctor"
        },
        pickdate: {
            required: "Plase Set Calender"
        },
        picktime: {
            required: "Plase Set Time"
        }
    },
    errorPlacement: function(error, element) {
        if (element.attr('name') == 'pickdate' || element.attr('name') == 'picktime') {
            error.insertAfter($(element.parent()));
        } else {
            error.insertAfter($(element));
        }


    }
})


$('#formSecondSubmit').click(function(event) {
    event.preventDefault();
    var valid = $('#RequestFormTwo').valid();
    if (valid) {
        $('.indicatorFirst').removeClass('active');
        $('.indicatorSecond').addClass('active');
        $('.successWrap').show();
        $('.requestSecondForm').hide();
        $('.submitBtn').hide();
    }
});


$('#formRejectReason').validate({
    rules: {
        rejectReason: {
            required: true
        }
    },
    messages: {
        rejectReason: {
            required: "please enter the reason for rejecting"
        }
    },
    errorPlacement: function(error, element) {
        error.insertAfter($(element));

    }
});

$('.rejectReason_submit').click(function() {
    var validInfo = ""
    $("form[data-form-validate='true']").each(function() {
        validInfo = $(this).valid();
    });

    if (validInfo) {
        $(this).parent().parent().parent().parent().parent().find(".cardReject_Input_wrapper").removeClass("inputSecEnabled");
    }
});


$("#filter_toggle").click(function() {
    $(".filter_wrapper").slideToggle(500);
});
