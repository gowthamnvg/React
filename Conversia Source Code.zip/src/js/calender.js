"use strict";


$("#calendar").fullCalendar({
    events: [{
            title: "Test",
            start: "2021-07-29",
            end: "2021-07-30"
        },
        {
            title: "Test",
            start: "2021-08-13",
            end: "2021-08-15"
        },
        {
            title: "Test",
            start: "2021-08-18",
            end: "2021-08-20"
        },
        {
            title: "Test",
            start: "2021-08-24",
            end: "2021-08-26"
        }
    ],
    eventAfterAllRender: function(view) {

        //Loop through all event to set the highlight and onclick url
        $(".fc-event-container").each(function() {

            // Get this day of the week number
            var weekDayIndex = $(this).index();
            // Get the calendar row
            var row = $(this).closest(".fc-row");
            // Get this date
            var date = row.find(".fc-day-top").eq(weekDayIndex).addClass("highlight").attr("data-date");
            // Add highlight and data-date
            row.find(".fc-day").eq(weekDayIndex)
                .addClass("highlight")
                .attr("data-date", date).append('<span class="requestStatus"></span>');
        });
    }
});


// Click handler
$(document).on("click", ".highlight", function() {
    alert($(this).data("date"));
});