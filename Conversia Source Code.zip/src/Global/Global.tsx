
export class GlobalConfig{
    private static _instance: GlobalConfig = new GlobalConfig();

   public accessToken : any; 
   public userName : any;
   public userType : any;
   public meeting : any=[];
   private constructor(){}
   public setToken(token:any){
       this.accessToken = token;
   }
    
   public getToken(){
       return this.accessToken;
   }

   public static get Instance(){
       return this._instance || (this._instance = new this());
   }
}
let Config : GlobalConfig = GlobalConfig.Instance;
export default Config
