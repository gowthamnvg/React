import classnames from "classnames";
import React from "react";
import Config from "../../Global/Global";
import { Link } from "react-router-dom";
export default class SeekerHeader extends React.Component {
    state: any = {
        signoutPopup: false
    }
    toggleHeaderPopup() {
        this.setState({ signoutPopup: !this.state.signoutPopup })
    }
    signOut(){
        sessionStorage.clear();
    }
    render() {
        return (
            <section>
            <header className="custmHeader">
                <div className="container">
                    <div className="headerWrap d-flex align-items-center justify-content-between">
                        <div className="leftContent">
                            <a href="">
                                <img src="assets/logo/conversia_logo.svg" alt="conversia_logo" />
                            </a>
                        </div>
                        <div className="rightContent">
                            <ul role="list" className="marginZero headerNavLists">
                                <li className="mbldisable"><Link to="/meetings" className="headerNavItem">All Requests</Link></li>
                                <li className="nav-item dropdown userToggle" style={{ cursor: "pointer" }} onClick={() => this.toggleHeaderPopup()}>
                                    <a className="nav-link dropdown-toggle" style={{ pointerEvents: "none", cursor: "pointer", color: "#FFFFFF" }} id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                        <span className="userIcon "><img src="assets/logo/userIcon.svg" alt="user_icon" width="15" height="15" />{sessionStorage.getItem("userName")}</span>
                                    </a>
                                    <div className={classnames("dropdown-menu", { "show": this.state.signoutPopup === true })} aria-labelledby="navbarDropdown" x-placement="bottom-start" style={{ position: "absolute", transform: "translate3d(0px, 30px, 0px)", top: "0px", left: "0px", willChange: "transform" }}>
                                        <a className="dropdown-item" onClick={()=>this.signOut()} href="/">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
             <section className="banner" style={{backgroundImage: `url("assets/logo/bannerImg.png")`}}>
             <div className="container">
                 <div className="bannerTextWrapper">
                     <h1>Detect early. Treat right</h1>
                 </div>
             </div>
         </section>
         </section>
        );
    }
}
