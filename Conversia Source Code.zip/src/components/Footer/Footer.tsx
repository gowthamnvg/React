import React from "react";
export default class Footer extends React.Component{
    render(){
        return(
            <footer className="footerBg footerSection">
            <div className="container">
                {/* <div className="row footerListRow">
                    <div className="col-6 col-md-2 col-lg-2 mb-5 mb-sm-5 mb-md-0 mb-lg-0">
                        <div className="footerNavs">
                            <ul role="list" className="footerNavList marginZero">
                                <li><a href="" target="_blank">Privacy Notice</a></li>
                                <li><a href="" target="_blank">Cookie Notice</a></li>
                                <li><a href="" target="_blank">Terms of Use</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-6 col-md-3 col-lg-3 mb-5 mb-sm-5 mb-md-0 mb-lg-0">
                        <div className="footerNavs">
                            <ul role="list" className="footerNavList marginZero">
                                <li><a href="" target="_blank">Contact Us</a></li>
                                <li><a href="" target="_blank">California Supplemental Disclosure</a></li>
                                <li><a href="" target="_blank">California Supply Chain
                                            Transparency, UK and Australia
                                            Modern Slavery Statement</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-6 col-md-2 col-lg-2 mb-5 mb-sm-5 mb-md-0 mb-lg-0">
                        <div className="footerNavs">
                            <ul role="list" className="footerNavList marginZero">
                                <li><a href="" target="_blank">Sitemap</a></li>
                                <li><a href="" target="_blank">About Us</a></li>
                                <li><a href="" target="_blank">Products</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-6 col-md-2 col-lg-2 mb-5 mb-sm-5 mb-md-0 mb-lg-0">
                        <div className="footerNavs">
                            <ul role="list" className="footerNavList marginZero">
                                <li><a href="" target="_blank">Careers</a></li>
                                <li><a href="" target="_blank">Investors</a></li>
                                <li><a href="" target="_blank">Newsroom</a></li>
                                <li><a href="" target="_blank">Cookies Settings</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-12 col-md-3 col-lg-3">
                        <div className="footerNavs footerSocialNavs d-flex align-items-center">
                            <p className="mr-5">Follow Us</p>
                            <ul role="list" className="footerNavList socialIconsList marginZero">
                                <li><a href="" target="_blank"><i className="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                <li><a href="" target="_blank"><i className="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="" target="_blank"><i className="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                */}
                <div className="row footerLogoRow">
                    <div className="col-12 col-sm-6 col-md-6  col-lg-6 mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                        <div className="footerLftLogo text-left">
                            <a href="" target="_blank">
                                <img src="assets/logo/viatris_logo.svg" alt="viatris_logo"/>
                            </a>
                        </div>
                    </div>
                    <div className="col-12 col-sm-6 col-md-6 col-lg-6 text-start text-sm-start text-md-right text-lg-right">
                        <div className="footerRgtLogo ">
                            <a href="" target="_blank">
                                <img src="assets/logo/gilead_logo.svg" alt="gilead_logo"/>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        );
    }
}