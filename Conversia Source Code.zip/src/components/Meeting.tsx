
import React, { useState } from "react";
import { RouteComponentProps } from "react-router-dom";
import { isDesktop } from 'react-device-detect';
import { connect, createLocalVideoTrack, LocalParticipant, LocalTrackOptions, LocalVideoTrack, MediaStreamTrackPublishOptions, RemoteParticipant, RemoteVideoTrackPublication, VideoTrack } from "twilio-video";
import { toast } from "react-toastify";
interface MeetingProps {
    sid: string,
    token: string,
    id: string,
    localParticipantName: string,
    remoteParticipantName: string,
    onMeetingEnd: () => void;
}
declare global {
    interface MediaDevices {
        getDisplayMedia(constraints: MediaStreamConstraints): Promise<MediaStream>;
    }
}
export default class Meeting extends React.Component<MeetingProps>{

    participantVideo: any = null;
    selfVideo: any = null;
    localTrack: any = null;
    participantSmallVideoView: any = null;
    state: any = {
        sid: '',
        token: '',
        id: '',
        room: null,
        participantName: '',
        mic: true,
        sharescreen: true,
        video: true,
        isVideoMuted: false,
        isParticipantConnected: false,
        remoteParticipantMic: true,
        isScreenShared: false,
        isRemoteVideoOff: false,
        isLocalVideoOff: true
    };
    remoteParticipant?: RemoteParticipant;
    localParticipant?: LocalParticipant;
    shareScreenTrack?: LocalVideoTrack;


    constructor(props: any) {
        super(props);
        this.state.sid = this.props.sid;
        this.state.token = this.props.token;
        this.state.id = this.props.id;
        this.participantVideo = React.createRef();
        this.selfVideo = React.createRef();
        this.participantSmallVideoView = React.createRef();
        this.participantConnected = this.participantConnected.bind(this);
        this.participantDisconnected = this.participantDisconnected.bind(this);
        this.trackSubscribed = this.trackSubscribed.bind(this);
        this.trackUnsubscribed = this.trackUnsubscribed.bind(this);
        this.onLocalTrack = this.onLocalTrack.bind(this);
        this.endMeeting = this.endMeeting.bind(this);
        // this.onDisconnectLocalTrack = this.onDisconnectLocalTrack.bind(this);
        //createLocalVideoTrack().then(this.onLocalTrack);
        this.connectToRoom(this.state.token, true, {
            height: { min: 240, max: 720 },
            frameRate: 24,
            width: { min: 320, max: 1280 }
        }, this.state.sid);
    }
    counter: any = 1;
    connectToRoom(token: any, audio: any, video: any, roomId: any) {
        try {
            connect(token, { name: roomId, audio: audio, video: video }).then(
                room => {
                    try {
                        const cameraTrack = [...room.localParticipant.videoTracks.values()][0].track;
                        this.localTrack = cameraTrack;
                        this.localParticipant = room.localParticipant;
                        this.selfVideo.current.appendChild(this.localTrack.attach());
                        this.state.isLocalVideoOff = false;
                    }
                    catch (error) { 
                        if(this.counter === 2){
                            toast.warn("Unable to access camera. Connected to the meeting using audio only")
                        }
                    }
                    this.state.room = room;
                    console.log('Connected to Room "%s"', room.name);
                    console.log(room);
                    room.on('participantConnected', this.participantConnected);
                    room.participants.forEach(this.participantConnected);
                    room.on('participantDisconnected', this.participantDisconnected);
                    room.once('disconnected', error => room.participants.forEach(this.participantDisconnected))
                    this.setState(this.state);
                }
            ).catch(error => {
                console.log(error);
                if (this.counter === 1) {
                    this.counter++;
                    this.connectToRoom(token, audio, false, roomId);
                }
                else {
                    toast.error("Unable to access camera and microphone! Please provide permission to access or enable in the settings", { onClose: this.endMeeting })
                }
            })
        }
        catch (error) {

        }
    }


    participantConnected(participant: any) {
        this.state.isParticipantConnected = true;
        this.remoteParticipant = participant;
        this.setState(this.state);
        console.log('Participant "%s" connected', participant.identity);
        this.state.participantName = participant.identity;
        participant.on('trackSubscribed', this.trackSubscribed);
        participant.on('trackUnsubscribed', this.trackUnsubscribed);
        participant.tracks.forEach((publication: any) => {
            if (publication.isSubscribed) {
                this.trackSubscribed(publication.track);
            }
            else {
                this.trackUnsubscribed(publication.track);
            }
        });
        this.setState(this.state);
        console.log(this.state);
    }
    participantDisconnected(participant: any) {
        this.state.isParticipantConnected = false;
        this.setState(this.state);
        console.log('Participant "%s" disconnected', participant.identity);
        // participant.tracks.forEach((track: any) => {
        //     const attachedElements = track.detach();
        //     attachedElements.forEach((element: any) => element.remove());
        // });
    }
    trackSubscribed(track: any) {
        try {
            console.log("Participant track subscribed : " + track.name);
            if (track.kind == "audio") {
                this.participantVideo.current.appendChild(track.attach());
                track.on('disabled', () => {
                    this.setState({ remoteParticipantMic: !this.state.remoteParticipantMic });
                    // do something with the UI here
                    console.log("Muted");
                });
                track.on('enabled', () => {
                    this.setState({ remoteParticipantMic: !this.state.remoteParticipantMic });
                    // do something with the UI here
                    console.log("Unmuted");
                });
            }
            if (track.kind == "video") {
                if (track.name == "screen") {

                    $("#participant-video-container video").remove();
                    this.state.isScreenShared = true;
                    this.participantVideo.current.appendChild(track.attach());
                    this.remoteParticipant?.videoTracks.forEach((videoTrack: RemoteVideoTrackPublication) => {
                        if (videoTrack.track?.name != "screen") {
                            this.participantSmallVideoView.current.appendChild(videoTrack.track?.attach());
                        }
                    })
                    track.on('disabled', () => {
                        $("#participant-video-container video").remove();

                        // do something with the UI here
                        console.log("remote screen share OFF");
                    });
                    track.on('enabled', () => {
                        this.participantVideo.current.appendChild(track.attach());
                        // do something with the UI here
                        console.log("remote screen share ON");
                    });
                    return;
                }
                if (this.state.isScreenShared) {
                    this.participantSmallVideoView.current.appendChild(track.attach());
                }
                else {
                    this.participantVideo.current.appendChild(track.attach());
                }
                track.on('disabled', () => {
                    $("#participant-video-container video").remove();
                    // do something with the UI here
                    console.log("Remote Video Removed");
                });
                track.on('enabled', () => {
                    // do something with the UI here
                    console.log("Remote Video Added");
                });
                this.state.isRemoteVideoOff = false;
                this.setState(this.state);
            }
        }
        catch (error) {
            console.log("Error in participant track sub : " + error);
        }
    }
    trackUnsubscribed(track: any) {

        try {
            console.log("Participant track Unsubscribed : " + track.kind);
            const attachedElements = track.detach();
            attachedElements.forEach((element: any) => element.remove());
            if (track.name == "screen") {
                $('#participant-video-small-container video').remove();
                this.state.isScreenShared = false;
                this.remoteParticipant?.videoTracks.forEach((videoTrack: RemoteVideoTrackPublication) => {
                    if (videoTrack.track?.name != "screen") {
                        this.participantVideo.current.appendChild(videoTrack.track?.attach());
                    }
                })
            } else {
                this.state.isRemoteVideoOff = true;
                this.setState(this.state);
            }

        }
        catch (error) {
            console.log("Error in Participant track Unsubscribed : " + error);
        }
    }
    onLocalTrack(track: any) {
        this.localTrack = track;
        //this.selfVideo.current.removeChild(this.selfVideo.current.children[0]);

        this.state.isLocalVideoOff = false;
        this.state.room.localParticipant.publishTrack(track);
        $("#video-div video").remove();
        this.selfVideo.current.appendChild(this.localTrack.attach());
        this.setState(this.state);
    }
    toggleMic() {
        this.setState({ mic: !this.state.mic });
        this.state.room.localParticipant.audioTracks.forEach((publication: any) => {
            (this.state.mic) ? publication.track.disable() : publication.track.enable();
        });
    }
    async toggleVideo() {
        if (!this.state.isLocalVideoOff) {
            this.state.room.localParticipant.unpublishTrack(this.localTrack);
            this.localTrack.stop();
            this.state.isLocalVideoOff = true;
            this.setState(this.state)
        }
        else {
            createLocalVideoTrack().then(this.onLocalTrack);
        }
    }
    endMeeting() {
        try {
            console.log("End Meeting");
            this.state.room.localParticipant.unpublishTrack(this.localTrack);
            this.localTrack.stop();
            this.state.room.disconnect();
        }
        catch (error) { }
        this.props.onMeetingEnd();
    }
    toggleScreen() {
        if (!this.shareScreenTrack) {
            navigator.mediaDevices.getDisplayMedia
                ({
                    audio: false,
                    video: {
                        frameRate: 10,
                        height: 1080,
                        width: 1920,
                    }
                })
                .then((stream: any) => {
                    this.shareScreenTrack = new LocalVideoTrack(stream.getTracks()[0], { name: "screen" } as LocalTrackOptions);
                    // this.shareScreenTrack.name = "screen";
                    // All video tracks are published with 'low' priority. This works because the video
                    // track that is displayed in the 'MainParticipant' component will have it's priority
                    // set to 'high' via track.setPriority()
                    this.state.room!.localParticipant
                        .publishTrack(this.shareScreenTrack, {
                            name: 'screen', // Tracks can be named to easily find them later
                            priority: 'low', // Priority is set to high by the subscriber when the video track is rendered
                        } as MediaStreamTrackPublishOptions);
                    this.shareScreenTrack.mediaStreamTrack.onended = () => {
                        this.toggleScreen();
                    }
                })
                .catch((error: any) => {
                    // Don't display an error if the user closes the screen share dialog
                    if (error.name !== 'AbortError' && error.name !== 'NotAllowedError') {
                        //   onError(error);
                    }
                });
        }
        else {
            this.state.room.localParticipant.unpublishTrack(this.shareScreenTrack);
            this.shareScreenTrack.stop();
            this.shareScreenTrack = undefined;
        }
    }
    render() {
        return (
            <div className="container-fluid">
                {
                    this.state.isParticipantConnected === true && (
                        <div className="remote-participant">{this.props.remoteParticipantName}</div>
                    )}
                <div className="fixed-top">
                    <div className="col-lg-12 col-md-12 col-sm-12 " style={{ backgroundColor: "grey", color: "white", textAlign: "center" }}>
                        {
                            this.state.isParticipantConnected === false && (
                                <div className="wait-message">Waiting for Participant to connect....</div>
                            )}
                    </div>

                    <div className="col-lg-5 col-md-5"></div>
                    <div className="col-lg-4 col-md-4"></div>
                </div>
                <div className="row">
                    <div className="small-video-container">
                        <div id="video-div" className="small-video-view" ref={this.selfVideo}>
                            {
                                this.state.isLocalVideoOff === true && (
                                    <div>{this.props.localParticipantName}</div>
                                )
                            }
                        </div>
                        <div id="participant-video-small-container" className="small-video-view" ref={this.participantSmallVideoView}>
                            {
                                this.state.isRemoteVideoOff === true && this.state.isParticipantConnected === true && (
                                    <div>{this.props.remoteParticipantName}</div>
                                )
                            }
                        </div>
                    </div>
                </div>
                <div>
                    <div id="participant-video-container" className="col-lg-12 col-md-12 col-xl-12 col-sm-12" style={{ padding: "0px" }} ref={this.participantVideo}></div>
                    <div className="fixed-bottom mic-detail">
                        <div style={{ textAlign: "center", position: "relative" }}>
                            {
                                this.state.remoteParticipantMic ? " " : <img src="assets/Localtrack/mic-disabled.png" />
                            }
                        </div>
                    </div>
                </div>

                <div className="fixed-bottom" style={{ display: "inline-flex" }} >
                    <div className="video-controls">
                        <div className="control-icon">{this.state.mic ? <img src="assets/icon/micOn.svg" onClick={() => this.toggleMic()} /> : <img src="assets/icon/micOff.svg" onClick={() => this.toggleMic()} />}</div>
                        {isDesktop === true && (
                            <div className="control-icon">{this.state.sharescreen ? <img src="assets/icon/shareScreen.svg" onClick={() => this.toggleScreen()} /> : <img src="assets/icon/shareScreen.svg" onClick={() => this.toggleScreen()} />}</div>
                        )}
                        <div className="control-icon">{this.state.isLocalVideoOff ? <img src="assets/icon/videooff.svg" onClick={() => this.toggleVideo()} /> : <img src="assets/icon/videoon.svg" onClick={() => this.toggleVideo()} />}</div>
                        <div className="control-icon"><img id="stop" src="assets/icon/call-end.svg" onClick={() => this.endMeeting()} /></div>
                    </div>
                </div>
            </div>
        )
    }
}