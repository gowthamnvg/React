import React from "react";
import classnames from "classnames";
import "../styles/style.css";
import { Link, RouteComponentProps } from "react-router-dom";
import Service from "../Service/Service";
import Footer from "../components/Footer/Footer";
import Header from "../components/Header/Header";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Modal } from "react-bootstrap";
interface JQuery {
    timepicker(params: any): any;
}
interface IProps { }
type HomeProps = IProps & RouteComponentProps;
interface IState { }
export default class NewRequest extends React.Component<HomeProps, IState> {
    selectedFiles: any = [];
    oldMeetingDetails: any = [];
    state: any = {
        showForm: true,
        user_id: 0,
        firstname: '',
        lastname: '',
        email_id: '',
        phone: '',
        createpwd: '',
        confirmpwd: '',
        hospital: '',
        city: '',
        doctorSelect: '',
        pickdate: '',
        picktime: '',
        description: '',
        specialty: '',
        completeRequest: false,
        errorMessage: '',
        files: [],
        followUprequest: undefined,
        isFollowRequestSucess: false,
        onAutoComplete: false,
        showProgressBar: false
    }
    constructor(props: any) {
        super(props);
        try {
            this.oldMeetingDetails = props.location.state.oldMeetingDetails;
            this.state.followUprequest = props.location.state.followUpRequest;
        }
        catch (error) {

        }
    }
    initialState() {
        return {
            showForm: true,
            firstname: '',
            lastname: '',
            email_id: '',
            phone: '',
            createpwd: '',
            confirmpwd: '',
            hospital: '',
            city: '',
            doctorSelect: '',
            pickdate: '',
            picktime: '',
            description: '',
            specialty: '',
            completeRequest: false,
            errorMessage: '',
            files: [],
            followUprequest: false,
            isFollowRequestSucess: false,
            onAutoComplete: false,
            showProgressBar: false
        }
    }
    onNewRequest() {
        this.setState(this.initialState);
        this.setState({ showForm: true, completeRequest: false, files: [], followUprequest: false });
        $('.indicatorFirst').addClass('active');
        $('.indicatorSecond').removeClass('active');
        $('.nextBtn').show();
    }
    uploadFiles(meetingId: any) {
        const filesUpload = new FormData();
        this.state.files.forEach((file: any) => {
            filesUpload.append("files", file);
        });
        new Service().fileUpload(filesUpload, meetingId).then(
            res => {
                this.setState({ showProgressBar: false });
                if (res.status === 200) {
                    this.setState({ showForm: false, completeRequest: true });
                    if (this.state.followUprequest === true) {
                        this.setState({ followUprequest: undefined }, () => { });
                    }
                } else if (res.status === 401) {
                    window.location.href = '/' as string;
                }
                else {
                    toast.error('Something went Wrong !')
                }

            }
        ).catch((error) => {
            toast.error('Something went Wrong !');
        })
    }
    updateList = (event: any) => {
        this.selectedFiles = Array.from(event.target.files);
        for (var i = 0; i < this.selectedFiles.length; i++) {
            this.state.files.push(this.selectedFiles[i]);
            this.setState(this.state.files);
            $("#fillselect").css('display', 'block');
        }
    }
    showFormOne() {
        $('.requestFirstForm').show();
        $('.requestSecondForm').hide();
        $('.nextBtn').show();
        $('.submitBtn').hide();
        $('.indicatorFirst').addClass('active');
        $('.indicatorSecond').removeClass('active');
    }
    toogleForm() {
        this.setState({ formTwo: true })
    }
    onValueChange = (event: any) => {
        this.setState({ [event.target.name]: event.target.value })
    }
    createMeeting() {
        this.setState({ showProgressBar: true });
        new Service().createMeeting(this.state).then(
            (res: any) => {
                if (res && res.status) {
                    if (res.status == 400) {
                        this.setState({ showProgressBar: false });
                        this.state.errorMessage = "Mismatch in data format, please verify.";
                        $('.submitBtn').show();
                    }
                    else if (res.status == 422) {
                        this.setState({ showProgressBar: false });
                        this.state.errorMessage = res.data;
                        $('.submitBtn').show();
                    }
                    else if (res.status == 200) {
                        this.uploadFiles(res.data.meeting_id);
                    }
                    else if (res.status == 401) {
                        this.setState({ showProgressBar: false });
                        window.location.href = '/' as string;
                    }
                    else {
                        this.setState({ showProgressBar: false });
                        this.state.errorMessage = "Unknown error.";
                        $('.submitBtn').show();
                    }
                    this.setState(this.state);
                }
                else {
                    console.log(res);
                }
            }
        )
    }
    createFollowUpMeeting() {
        this.setState({ showProgressBar: true });
        let meetingDetails = {};
        meetingDetails = {
            user_id: this.oldMeetingDetails.doctor_id,
            expert_id: this.oldMeetingDetails.expert_id,
            meeting_date: this.state.pickdate + "T" + this.state.picktime,
            follow_up_on: this.oldMeetingDetails.meeting_id
        }
        new Service().followUpMeeting(meetingDetails).then(
            res => {
                this.setState({ showProgressBar: false });
                if (res.status === 200) {
                    if (this.state.files.length != 0) {
                        this.uploadFiles(res.data.meeting_id);
                    } else {
                        this.setState({ showForm: false, completeRequest: true });
                        if (this.state.followUprequest === true) {
                            this.setState({ followUprequest: undefined }, () => { });
                        }
                    }

                }
            }
        )
    }
    handleChangeDate = (date: any, event: any) => {
        this.setState({
            date
        });
    }
    onfocusInput() {
        document.getElementById("validationMsgDiv")!.style.display = "block";
    }
    onkeyupInput() {
        var myInput = (document.getElementById("createPassword")! as HTMLInputElement);
        var capital = (document.getElementById("capital")! as HTMLInputElement);
        var number = (document.getElementById("number")! as HTMLInputElement);
        var length = (document.getElementById("length")! as HTMLInputElement);
        var passStatus = false;

        // Validate length
        if (myInput.value.length >= 8) {
            length.classList.remove("valInfoTx");
            length.classList.remove("invalid");
            length.classList.add("valid");
        } else {
            length.classList.remove("valid");
            length.classList.add("invalid");
        }

        // Validate capital letters
        var upperCaseLetters = /[A-Z]/g;
        if (myInput.value.match(upperCaseLetters)) {
            capital.classList.remove("valInfoTx");
            capital.classList.remove("invalid");
            capital.classList.add("valid");
        } else {
            capital.classList.remove("valid");
            capital.classList.add("invalid");
        }

        // Validate numbers
        var numbers = /[0-9]/g;
        if (myInput.value.match(numbers)) {
            number.classList.remove("valInfoTx");
            number.classList.remove("invalid");
            number.classList.add("valid");
        } else {
            number.classList.remove("valid");
            number.classList.add("invalid");
        }
        if (myInput.value.length >= 8 && myInput.value.length <= 15 && myInput.value.match(upperCaseLetters) && myInput.value.match(numbers)) {

            document.getElementById("validationMsgDiv")!.style.display = "none";

        } else {
            document.getElementById("validationMsgDiv")!.style.display = "block";
        }

    }
    componentDidUpdate() {
        ($('#timepicker') as any).timepicker({
            timeFormat: 'h:mm p',
            interval: 10,
            maxHour: 24,
            defaultTime: 'set Time',
            startTime: new Date(0, 0, 0, 12, 0, 0),
            dynamic: false,
            dropdown: true,
            scrollbar: true,
            change: ((val: any) => {
                if (val instanceof Date) {
                    this.setState({ picktime: (val.getHours() < 10 ? "0" : "") + val.getHours() + ":" + (val.getMinutes() < 10 ? "0" : "") + val.getMinutes() })
                }
            })
        });
        ($('#datepicker') as any).datepicker({
            format: 'yyyy-mm-dd',
            todayBtn: "linked",
            todayHighlight: true,
            orientation: "bottom",
            showButtonPanel: true
        }).change((val: any) => {
            this.setState({ pickdate: val.target.value });
        })
    }
    componentDidMount() {
        ($('#timepicker') as any).timepicker({
            timeFormat: 'h:mm p',
            interval: 10,
            maxHour: 24,
            defaultTime: 'set Time',
            startTime: new Date(0, 0, 0, 12, 0, 0),
            dynamic: false,
            dropdown: true,
            scrollbar: true,
            change: ((val: any) => {
                if (val instanceof Date) {
                    this.setState({ picktime: (val.getHours() < 10 ? "0" : "") + val.getHours() + ":" + (val.getMinutes() < 10 ? "0" : "") + val.getMinutes() })
                }
            })
        });
        ($('#datepicker') as any).datepicker({
            format: 'yyyy-mm-dd',
            todayBtn: "linked",
            todayHighlight: true,
            orientation: "bottom",
            showButtonPanel: true
        }).change((val: any) => {
            this.setState({ pickdate: val.target.value });
        })
        // new request first form validation
        if (this.state.onAutoComplete === false) {
            $('#RequestFormOne').validate({
                rules: {
                    fname: {
                        required: true
                    },
                    Lname: {
                        required: true
                    },
                    email_id: {
                        required: true,
                        email: true
                    },
                    phoneNumber: {
                        required: true,
                    },
                    createpwd: {
                        required: true
                    },
                    confirmpwd: {
                        required: true,
                        equalTo: "#createPassword"
                    },
                    hospital: {
                        required: true
                    },
                    city: {
                        required: true
                    },
                    specility: {
                        required: true
                    },
                    file: {
                        required: true
                    }
                },
                messages: {
                    fname: {
                        required: "Please provide seeker first name."
                    },
                    Lname: {
                        filerequired: "Please provide seeker last name."
                    },
                    email_id: {
                        required: "Please provide seeker e-mail id.",
                        email: "Please provide a valid e-mail id."
                    },
                    phoneNumber: {
                        required: "Please provide phone number.",
                    },
                    createpwd: {
                        required: "Please provide password."
                    },
                    confirmpwd: {
                        required: "Please provide password.",
                        equalTo: "Password mismatch."

                    },
                    hospital: {
                        required: "Please provide hospital name."
                    },
                    city: {
                        required: "Please provide city."
                    },
                    specility: {
                        required: "Please select specility."
                    },
                    file: {
                        required: "Please select files to upload."
                    }
                },
                errorPlacement: function (error, element) {
                    if (element.attr("type") == "file") {
                        error.insertAfter($(element).parent(".browseWrap"));
                    } else {
                        error.insertAfter($(element));
                    }

                }
            })
        }
        //new request second form validation
        $('#RequestFormTwo').validate({
            rules: {
                doctorSelect: {
                    required: true
                },
                pickdate: {
                    required: true
                },
                picktime: {
                    required: true
                }
            },
            messages: {
                doctorSelect: {
                    required: "Please Select Doctor"
                },
                pickdate: {
                    required: "Plase Set Calender"
                },
                picktime: {
                    required: "Plase Set Time"
                }
            },
            errorPlacement: function (error, element) {
                if (element.attr('name') == 'pickdate' || element.attr('name') == 'picktime') {
                    error.insertAfter($(element.parent()));
                } else {
                    error.insertAfter($(element));
                }


            }
        })
        $('#followUpRequest').validate({
            rules: {
                doctorSelect: {
                    required: true
                },
                pickdate: {
                    required: true
                },
                picktime: {
                    required: true
                }
                // file: {
                //     required: true
                // }
            },
            messages: {
                doctorSelect: {
                    required: "Please Select Doctor"
                },
                pickdate: {
                    required: "Plase Set Calender"
                },
                picktime: {
                    required: "Plase Set Time"
                }
                // file: {
                //     required: "Please select files to upload."
                // }
            },
        })



        if (this.state.onAutoComplete === false) {

            $('#formFirstSubmit').click(function (event) {
                event.preventDefault();
                var valid = $('#RequestFormOne').valid();
                if (valid) {
                    $('.indicatorFirst').removeClass('active');
                    $('.indicatorSecond').addClass('active');
                    $('.requestFirstForm').hide();
                    $('.requestSecondForm').show();
                    $('.nextBtn').hide();
                    $('.submitBtn').show();
                }
            })
        }
        $('#formSecondSubmit').click(function (event) {
            event.preventDefault();
            var valid = $('#RequestFormTwo').valid();
            if (valid) {
                $('.indicatorFirst').removeClass('active');
                $('.indicatorSecond').addClass('active');
                $('.successWrap').show();
                $('.submitBtn').hide();
            }
        });

        $('#followUpRequestSubmit').click(function (event) {
            event.preventDefault();
            var valid = $('#followUpRequest').valid();
            if (valid) {
                $('.indicatorFirst').hide();
                $('.indicatorSecond').hide();
                $('.successWrap').show();
                $('.submitBtn').hide();
                $('.nextBtn').hide();
                $('#formFirstSubmit').css('display', 'none');
                $('.customPageIndicationWrap').hide();
            }
        });
    }

    searchUser() {
        new Service().searchUser(this.state.email_id).then(
            res => {
                if (res.status === 200) {
                    this.state.firstname = res.data.firstname;
                    this.state.lastname = res.data.lastname;
                    this.state.email_id = res.data.email_id;
                    this.state.phone = res.data.phone;
                    this.state.hospital = res.data.hospital;
                    this.state.city = res.data.city;
                    this.state.specialty = res.data.specialty;
                    this.state.onAutoComplete = true;
                    this.state.user_id = res.data.user_id;
                    this.setState(this.state);
                }
            }
        ).catch(res => { })
    }
    render() {
        return (
            <main>
                <Header />
                <section className="formSection">
                    <div className="container">
                        <div className="row">
                            <div className="col-12 mx-sm-auto col-sm-10 col-md-10 col-lg-9">
                                <div className="LoginBox shadow_1">
                                    <div className="requestTitleSec mb-5 text-center">
                                        {this.state.followUprequest === true && (
                                            <span>
                                                <h2 className="text-uppercase mb-3">FOLLOW UP REQUEST</h2>
                                                <p className="p14">Please update seekers details below</p>
                                            </span>
                                        )
                                        }
                                        {this.state.followUprequest === false && (
                                            <span>
                                                <h2 className="text-uppercase mb-3">New Request</h2>
                                                <p className="p14">Please update seekers details below</p>
                                            </span>
                                        )
                                        }

                                    </div>
                                    {this.state.followUprequest === false && (
                                        <span>
                                            {this.state.showForm === true && (
                                                <span>
                                                    <form id="RequestFormOne" className="requestFirstForm">
                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6 form-group mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="text" className="form-control CstmInput" name="firstname" value={this.state.firstname} placeholder="First Name" required onChange={this.onValueChange} />
                                                            </div>
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6 form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="text" className="form-control CstmInput" name="lastname" value={this.state.lastname} placeholder="Last Name" required onChange={this.onValueChange} />
                                                            </div>
                                                        </div>
                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6 form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="email" className="form-control CstmInput" name="email_id" value={this.state.email_id} placeholder="Email ID" required onChange={this.onValueChange} onBlur={() => this.searchUser()} />
                                                            </div>
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6l form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="number" className="form-control CstmInput" name="phone" value={this.state.phone} placeholder="Phone Number" minLength={10} maxLength={10} required onChange={this.onValueChange} />
                                                            </div>
                                                        </div>
                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6 form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="password" className="form-control CstmInput" id="createPassword" name="createpwd" required placeholder="Create Password" onFocus={() => this.onfocusInput()} onKeyUp={() => this.onkeyupInput()} onChange={this.onValueChange} />
                                                                <div id="validationMsgDiv" className="mt-4" style={{ display: "none" }}>
                                                                    <p id="capital" className="valInfoTxt  p12"> At least one uppercase character.</p>
                                                                    <p id="number" className="valInfoTxt  p12"> Contain at least one digit.</p>
                                                                    <p id="length" className="valInfoTxt  p12"> At least 8 characters in length.</p>
                                                                </div>
                                                            </div>
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6l form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="password" className="form-control CstmInput" name="confirmpwd" placeholder="Confirm Password" required onChange={this.onValueChange} />
                                                            </div>
                                                        </div>
                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6 form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="text" className="form-control CstmInput" name="hospital" value={this.state.hospital} placeholder="Hospital" required onChange={this.onValueChange} />
                                                            </div>
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6l form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="text" className="form-control CstmInput" name="city" value={this.state.city} placeholder="City" required onChange={this.onValueChange} />
                                                            </div>
                                                        </div>
                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 form-group fullPadding  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <input type="text" className="form-control CstmInput" name="specialty" value={this.state.specialty} placeholder="Speciality" required onChange={this.onValueChange} />
                                                            </div>

                                                        </div>

                                                        <div className="form-row mb-0">
                                                            <div className="col-12 form-group fullPadding  mb-0 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <div className="browseWrap">
                                                                    <p className="p14 text-uppercase text_bold">Browse Attachments</p>
                                                                    <input type="file" name="file" id="file" required multiple onChange={this.updateList} className="upload" title="Choose a file to upload" />
                                                                </div>

                                                                <p className={classnames("",)} id="fillselect" style={{ display: "none" }}>Selected files:</p>
                                                                <div id="fileList" className="mt-3">
                                                                    <ul>
                                                                        {
                                                                            this.state.files.map((file: any, index: any) =>
                                                                            (
                                                                                <li key={index} style={{ listStyleType: "none" }}>
                                                                                    {file.name}
                                                                                </li>
                                                                            ))
                                                                        }
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </form>
                                                    <form id="RequestFormTwo" className="requestSecondForm">
                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 form-group fullPadding  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <select className="form-control CstmSelect" name="doctorSelect" id="" required onClick={this.onValueChange}>
                                                                    <option value="">Select Doctor</option>
                                                                    <option value="2">Dr. Neha Gupta</option>
                                                                    <option value="3">Dr. Parikshit Prayag</option>
                                                                    <option value="4">Dr. Vishnu Rao</option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6 form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <div className="datetimeDiv">
                                                                    <input data-provide="datepicker" className="form-control CstmInput dateField" id="datepicker" name="pickdate" placeholder="Set Calendar" required />
                                                                    <img src="assets/logo/calender_icon.svg" alt="calender_icon" />
                                                                </div>
                                                            </div>
                                                            <div className="col-12 col-sm-6 col-md-6 col-lg-6l form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                                <div className="datetimeDiv">
                                                                    <input type="text" className="form-control CstmInput timepicker" id="timepicker" name="picktime" placeholder="Set Time" required />
                                                                    <img src="assets/logo/timer_icon.svg" alt="timer_icon" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                            <div className="col-12 col-sm-12 col-md-12 col-lg-12 form-group fullPadding">
                                                                <textarea className="CstmInput CstmTextArea" id="description" name="description" rows={5} placeholder="Descriptions" onClick={this.onValueChange}></textarea>
                                                                <p className="p12 mt-3 text-uppercase" style={{ color: "#626262" }}>Not mandatory</p>
                                                            </div>

                                                        </div>
                                                        <div className="formsSubmitWrap mt-5 text-right d-flex align-items-center justify-content-start">
                                                            <div className="error-message mr-5 error" style={{ color: '#ff0000', fontSize: '10px' }}>
                                                                {this.state.errorMessage}
                                                            </div>

                                                        </div>
                                                    </form>
                                                </span>
                                            )}
                                        </span>
                                    )}
                                    {
                                        this.state.followUprequest === true && (

                                            <form id="followUpRequest" className="follup-request">
                                                <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                    <div className="col-12 form-group fullPadding  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                        <select className="form-control CstmSelect" name="doctorSelect" id="" required onClick={this.onValueChange}>
                                                            <option value="">Select Doctor</option>
                                                            <option value="2">Dr. Neha Gupta</option>
                                                            <option value="3">Dr. Parikshit Prayag</option>
                                                            <option value="4">Dr. Vishnu Rao</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                    <div className="col-12 col-sm-6 col-md-6 col-lg-6 form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                        <div className="datetimeDiv">
                                                            <input data-provide="datepicker" className="form-control CstmInput dateField" id="datepicker" name="pickdate" placeholder="Set Calendar" required />
                                                            <img src="assets/logo/calender_icon.svg" alt="calender_icon" />
                                                        </div>
                                                    </div>
                                                    <div className="col-12 col-sm-6 col-md-6 col-lg-6l form-group  mb-5 mb-sm-0 mb-md-0 mb-lg-0">
                                                        <div className="datetimeDiv">
                                                            <input type="text" className="form-control CstmInput timepicker" id="timepicker" name="picktime" placeholder="Set Time" required />
                                                            <img src="assets/logo/timer_icon.svg" alt="timer_icon" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-row mb-0 mb-sm-5 mb-md-5 mb-lg-5">
                                                    <div className="col-12 col-sm-12 col-md-12 col-lg-12 form-group fullPadding">
                                                        <textarea className="CstmInput CstmTextArea" id="description" name="description" rows={5} placeholder="Descriptions" onClick={this.onValueChange}></textarea>
                                                        <p className="p12 mt-3 text-uppercase" style={{ color: "#626262" }}>Not mandatory</p>
                                                    </div>

                                                </div>
                                                <div className="formsSubmitWrap mt-5 text-right d-flex align-items-center justify-content-start">
                                                    <div className="error-message mr-5 error" style={{ color: '#ff0000', fontSize: '10px' }}>
                                                        {this.state.errorMessage}
                                                    </div>

                                                </div>
                                                <div className="form-row mb-0">
                                                    <div className="col-12 form-group fullPadding  mb-0 mb-sm-0 mb-md-0 mb-lg-0">
                                                        <div className="browseWrap">
                                                            <p className="p14 text-uppercase text_bold">Browse Attachments</p>
                                                            <input type="file" name="file" id="file" multiple onChange={this.updateList} className="upload" />
                                                        </div>

                                                        <p className={classnames("",)} id="fillselect" style={{ display: "none" }}>Selected files:</p>
                                                        <div id="fileList" className="mt-3">
                                                            <ul>
                                                                {
                                                                    this.state.files.map((file: any, index: any) =>
                                                                    (
                                                                        <li key={index} style={{ listStyleType: "none" }}>
                                                                            {file.name}
                                                                        </li>
                                                                    ))
                                                                }
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        )}
                                    {this.state.completeRequest === true && (
                                        <div className="successWrap">
                                            <div className="row">
                                                <div className="col-12 text-center">
                                                    <div className="successBox">
                                                        <div className="successCircle"></div>
                                                        <p className="successText">The request has been successfully shared!</p>
                                                    </div>
                                                    <Link onClick={() => this.onNewRequest()} to="/newrequest" className="btn" id="NewRequestAgain">New Request</Link>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                                <div className="formsSubmitWrap mt-5 text-right d-flex align-items-center justify-content-end">
                                    {
                                        this.state.followUprequest === false && (
                                            <div className="customPageIndicationWrap mr-5">
                                                <ul className="marginZero" role="list">
                                                    <li onClick={() => this.showFormOne()}><span className="pageIndicator indicatorFirst mr-4 active"></span></li>
                                                    <li><span className="pageIndicator indicatorSecond"></span></li>
                                                </ul>
                                            </div>
                                        )
                                    }
                                    <div className="formsButtonWrap">
                                        {
                                            this.state.followUprequest === false && (
                                                <span>
                                                    <button type="submit" id="formFirstSubmit" className="btn btn_min nextBtn">Next</button>
                                                    <button type="submit" id="formSecondSubmit" className="btn btn_min submitBtn" onClick={() => this.createMeeting()}>Submit</button>
                                                </span>
                                            )
                                        }
                                        {
                                            this.state.followUprequest === true && (

                                                <button type="submit" id="followUpRequestSubmit" className="btn btn_min submitBtn" onClick={() => this.createFollowUpMeeting()}>Submit</button>
                                            )
                                        }
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <Modal show={this.state.showProgressBar} backdrop="static">
                        <div className="container">
                            <img className="gif" src="assets/icon/Loader.gif" />
                        </div>
                    </Modal>
                    <ToastContainer
                        position="top-right"
                        autoClose={5000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable={false}
                        pauseOnHover
                        theme='colored'
                    />
                </section>
                <Footer />
            </main>
        );
    }
}