import React from "react";
import { Link, RouteComponentProps } from "react-router-dom";
import Meeting from "../components/Meeting";
import Service from "../Service/Service";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
interface IProps { }
type HomeProps = IProps & RouteComponentProps;
interface IState { }
export default class MeetingPage extends React.Component<HomeProps, IState> {
    value: any = '';
    state: any = {
        meetingToken: '',
        meetingSid: '',
        isMeetingView: false,
        RemoteParticipantName: '',
        LocalParticipantName: ''
    }
    constructor(props: any) {
        super(props);
        this.state.LocalParticipantName = sessionStorage.getItem("userName");
        this.gotoMeetingList = this.gotoMeetingList.bind(this);
        this.value = this.props.location.state;
        this.state.meetingSid = this.value.meeting_sid;
        if (sessionStorage.getItem("userType") === "EXPERT") {
            this.state.RemoteParticipantName = this.value.doctor.firstname;
            this.setState(this.state);
        } else if (sessionStorage.getItem("userType") === "DOCTOR") {
            this.state.RemoteParticipantName = this.value.expert.firstname;
            this.setState(this.state);
        }
        new Service().getMeetingToken(this.state.meetingSid).then(
            res => {
                if (res.status === 200) {
                    this.state.meetingToken = res.data.token;
                    this.state.isMeetingView = true;
                    this.setState(this.state);
                }
                else if (res.status === 401) {
                    window.location.href = "/" as string;
                }
                else {
                    toast.error('Something went Wrong !');
                }

            }
        )
    }
    gotoMeetingList() {
        this.props.history.push("/meetings");
    }
    render() {
        return (
            <span>
                <ToastContainer
                    position="top-right"
                    autoClose={5000}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick
                    rtl={false}
                    pauseOnFocusLoss
                    draggable={false}
                    pauseOnHover
                    theme='colored'
                />
                {this.state.isMeetingView === true && (
                    <Meeting sid={this.state.meetingSid} token={this.state.meetingToken} id={this.state.meetingId} localParticipantName={this.state.LocalParticipantName} onMeetingEnd={this.gotoMeetingList} remoteParticipantName={this.state.RemoteParticipantName}></Meeting>
                )}
            </span>
        )
    }
}