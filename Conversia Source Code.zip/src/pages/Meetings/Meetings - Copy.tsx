import React from "react";
import { Modal } from "react-bootstrap";
import { Link } from "react-router-dom"
import "../../styles/global.css"
import Service from "../../Service/Service";
import Fullcalendar from "@fullcalendar/react";
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import Moment from "react-moment";
import $ from "jquery";
import moment from "moment";
import Header from "../../components/Header/Header";
import SeekerHeader from "../../components/SeekerHeader/SeekerHeader";
import Footer from "../../components/Footer/Footer";
import classNames from "classnames";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
export default class Meetings extends React.Component {
    state: any = {
        viewUploadedFiles: false,
        meetingDetails: [],
        year: '',
        month: '',
        week: '',
        meetingToken: '',
        meetingSid: '',
        filterByDate: {
            startDate: '',
            endDate: ''
        },
        files: [],
        userType: '',
        events: [],
        isCurrentWeek: true,
        filterBy: 'All',
        completedRequest: [],
        meetingRejectionConfirmation: false,
        rejectReason: '',
        weekCount: 0,
        weekNumbers: ["1st", "2nd", "3rd", "4th", "5th", "6th"]
    }
    filterMeetingDetails: any = [];
    completeDetails: any = [];
    fileToUpload: any = [];
    fileList: any = [];
    constructor(props: any) {
        super(props);
        this.state.userType = sessionStorage.getItem("userType");
        this.getMeetings();

    }
    getMeetings() {
        new Service().getMeetingDetails().then(
            res => {
                if (res.status === 200) {
                    this.state.events = [];
                    this.completeDetails = res.data;
                    this.completeDetails.sort((a: any, b: any) => (new Date(a.meeting_date) < new Date(b.meeting_date) ? 1 : -1));
                    this.state.meetingDetails = this.completeDetails.slice();
                    for (var index = 0; index < this.state.meetingDetails.length; index++) {
                        var eventDate = new Date(this.state.meetingDetails[index].meeting_date);
                        var date = eventDate.getFullYear() + "-" + (((eventDate.getMonth() + 1) < 10 ? "0" : "") + (eventDate.getMonth() + 1)) + "-" + eventDate.getDate();
                        var temp = this.state.events.find((a: any) => { return a.date == date });
                        if (temp === undefined)
                            this.state.events.push({ date: date, title: date });
                    }
                    this.setCurrentWeek();
                    this.setState(this.state.events);
                }
                else if (res.status === 401) {
                    window.location.href = "/" as string;
                }
                else {
                    toast.error('Something went Wrong !');
                }
            }
        ).catch((error) => {
            console.log(error);
            toast.error('Something went Wrong !');
        })
    }
    setCurrentWeek() {
        var now = new Date();
        this.state.year = now.getFullYear();
        this.state.month = now.getMonth();
        this.state.week = this.getWeekOfMonth(now);
        this.filterMeetings()
    }
    handleModal(details: any) {
        // console.log(details);
        if (!this.state.viewUploadedFiles) {
            new Service().getFiles(details.meeting_id).then(
                res => {
                    this.state.files = res;
                    this.setState(this.state);
                }
            )
        }
        this.setState({ viewUploadedFiles: !this.state.viewUploadedFiles })
    }
    onChangeYear = (event: any) => {
        this.setState({ [event.target.name]: event.target.value }, () => this.checkYear());

    }
    onChangeMonth = (event: any) => {
        var lastDay = new Date(this.state.year, event.target.value, 0);
        this.state.weekCount = this.getWeekCountOfMonth(lastDay);
        this.setState({ [event.target.name]: (event.target.value - 1) }, () => this.checkMonth());

    }
    onChangeweek = (event: any) => {
        this.setState({ [event.target.name]: event.target.value }, () => this.filterMeetings());

    }
    checkYear() {
        if (this.state.year !== "" && this.state.year !== "year") {
            $("#month").prop('disabled', false);
            this.checkMonth();
        }
        else {
            $("#month").prop('disabled', true);
        }
        if ((this.state.year === "" || this.state.year === "year") &&
            (this.state.month === "" || this.state.month === "month") &&
            (this.state.week === "" || this.state.week === "week")) {
            this.state.meetingDetails = this.completeDetails.slice();
            this.setState(this.state);
        }
    }
    checkMonth() {
        if (this.state.month !== "" && this.state.month !== "month") {
            $("#week").prop('disabled', false);
            this.filterMeetings();
        }
        else {
            $("#week").prop('disabled', true);
        }
    }
    filterMeetings() {
        if (this.state.week !== "" && this.state.week !== "week") {
            this.state.filterByDate.startDate = this.getFirstDateOfWeek(this.state.week, this.state.month, this.state.year);
            this.state.filterByDate.endDate = this.getFirstDateOfWeek(this.state.week, this.state.month, this.state.year);
            this.state.filterByDate.endDate.setDate(this.state.filterByDate.endDate.getDate() + 6);
            var currentDate = new Date();
            var currentWeekFirstDate = this.getFirstDateOfWeek(this.getWeekOfMonth(currentDate), currentDate.getMonth(), currentDate.getFullYear());
            this.state.isCurrentWeek = (currentWeekFirstDate.toString() == this.state.filterByDate.startDate.toString());
            this.filterMeetingByRange(this.state.filterByDate);
        }
    }
    convertToDateFormat(dates: any) {
        let date = new Date(dates),
            mnth = ("0" + (date.getMonth() + 1)).slice(-2),
            day = ("0" + date.getDate()).slice(-2);
        return [date.getFullYear(), mnth, day].join("-");
    }
    filterMeetingByRange(filterDate: any) {
        this.filterMeetingDetails = [];
        let startDate = this.convertToDateFormat(filterDate.startDate);
        let endDate = this.convertToDateFormat(filterDate.endDate);
        let convertedStartDate = new Date(startDate).setHours(0, 0, 0, 0);
        let convertedEndDate = new Date(endDate).setHours(0, 0, 0, 0);
        this.completeDetails.forEach((detail: any) => {
            if ((new Date(detail.meeting_date).setHours(0, 0, 0, 0)) >= convertedStartDate && (new Date(detail.meeting_date).setHours(0, 0, 0, 0)) <= convertedEndDate) {
                if (this.state.filterBy === "All" || this.state.filterBy === detail.status)
                    this.filterMeetingDetails.push(detail);
            }
        });
        this.state.meetingDetails = [];
        this.state.meetingDetails = this.filterMeetingDetails;
        this.setState(this.state);
    }
    uploadFiles = (event: any, meetingId: any) => {
        this.fileToUpload = Array.from(event.target.files);
        for (var i = 0; i < this.fileToUpload.length; i++) {
            this.fileList.push(this.fileToUpload[i]);
            this.setState(this.fileList);
        }
        const filesUpload = new FormData();
        this.fileList.forEach((file: any) => {
            filesUpload.append("files", file);
        });
        new Service().fileUpload(filesUpload, meetingId).then(
            res => {
                // this.setState({ completeRequest: true });
            }
        );
    }
    componentDidMount() {
        $("#filter_toggle").click(function () {
            $(".filter_wrapper").slideToggle(500);
        });
        $("#week").prop('disabled', 'true');
        $("#month").prop('disabled', 'true');
    }
    downloadfile(file: any) {
        new Service().fileDownload(file.meeting_id, file.file_id).then(
            res => {

                this.saveByteArray(file.name, res);
            }
        )
    }
    saveByteArray(fileName: any, byte: any) {
        var blob = new Blob([byte]);
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = fileName;
        link.click();
    }
    getFirstDateOfWeek(weekNumber: any, month: any, year: any) {
        var d = (1 + (weekNumber - 1) * 7);
        let firstDate = new Date(year, month, d - (new Date(year, month, 1).getDay()));
        return firstDate;
    }
    getWeekCountOfMonth(date: Date) {
        let adjustedDate = date.getDate() + (new Date(date.getFullYear(), date.getMonth(), 1).getDay());
        return Math.ceil(adjustedDate / 7);
    }
    getWeekOfMonth(date: Date) {
        let adjustedDate = date.getDate() + (new Date(date.getFullYear(), date.getMonth(), 0).getDay());
        let prefixes = ['0', '1', '2', '3', '4', '5'];
        return (parseInt(prefixes[0 | adjustedDate / 7]) + 1);
    }
    onDateClicked = (dateInfo: any) => {
        this.state.year = dateInfo.date.getFullYear();
        this.state.month = dateInfo.date.getMonth();
        this.state.week = this.getWeekOfMonth(dateInfo.date);
        this.filterMeetings();
    }
    changeRequest(requestType: any) {
        this.state.filterBy = requestType;
        this.filterMeetings();
        this.setState(this.state);
    }
    handleMeetingRejectionModal() {
        this.setState({ meetingRejectionConfirmation: !this.state.viewUploadedDocument })
    }
    rejectMeetingConfirmation() {
        this.setState({ meetingRejectionConfirmation: true });
    }
    rejectionReason = (event: any) => {
        this.setState({ [event.target.name]: event.target.value });
    }
    rejectMeeting(status: any, detail: any) {
        if (status === "yes") {
            new Service().rejectMeeting(detail.meeting_id, this.state.rejectReason).then(
                res => {
                    if (res === 200) {
                        this.getMeetings();
                        this.setState({ meetingRejectionConfirmation: false });
                        toast.success("Meeting Rejected Successfully")
                    }
                }
            )
        } else {
            this.setState({ meetingRejectionConfirmation: false });
        }
    }
    showReason(index: any) {
        $('#rid' + index).toggle();
        $('#vrid' + index).toggleClass("ri_active");
    }
    render() {
        $(document).ready(function () {
            $(".btn_reject").click(function () {
                $(this).toggleClass("btn_disabled");
                $(this).parent().parent().parent().parent().parent().find(".cardRequest").toggleClass("fi_active");
                $(this).parent().parent().parent().parent().parent().find(".cardReject_Input_wrapper").addClass("inputSecEnabled");
            });
        });
        return (
            <span>
                {this.state.userType === "TELECALLER" ? <Header /> : <SeekerHeader />}
                <section className="innerAllRqst_sec">
                    <div className="container">
                        <div className="">
                            <h4>All Request</h4>
                        </div>
                        <ul className="nav nav_tabs my-5" id="myTab" role="tablist">
                            <div className="selector"></div>
                            <li className="nav-item ">
                                <div style={{ cursor: "pointer" }} className={classNames("nav-link", { "active": this.state.filterBy === 'All' })} onClick={() => this.changeRequest("All")}>All</div>
                            </li>
                            <li className="nav-item">
                                <div style={{ cursor: "pointer" }} className={classNames("nav-link", { "active": this.state.filterBy === 'NOT_STARTED' })} onClick={() => this.changeRequest("NOT_STARTED")}>Upcoming</div>
                            </li>
                            <li className="nav-item">
                                <div style={{ cursor: "pointer" }} className={classNames("nav-link", { "active": this.state.filterBy === 'COMPLETED' })} onClick={() => this.changeRequest("COMPLETED")}>Completed</div>
                            </li>
                            <li className="nav-item">
                                <div style={{ cursor: "pointer" }} className={classNames("nav-link", { "active": this.state.filterBy === 'REJECTED' })} onClick={() => this.changeRequest("REJECTED")}>Rejected</div>
                            </li>
                        </ul>


                        <div className="row">
                            <div className="col-12 order-2 col-md-8 order-md-1 col-lg-9">
                                <div className="filters mb-5">
                                    <div className="d-flex align-items-center justify-content-between">
                                        <div>
                                            {
                                                this.state.isCurrentWeek === true && (

                                                    <p className="text_bold">This Week</p>
                                                )}
                                            {
                                                this.state.isCurrentWeek === false && (
                                                    <p className="text_bold">Week : {this.state.filterByDate.startDate.toDateString()} - {this.state.filterByDate.endDate.toDateString()}</p>
                                                )
                                            }
                                        </div>
                                        <div className="d-flex align-items-center">
                                            <p className="d-flex align-items-center p14 color_959595" id="filter_toggle">
                                                <img src="assets/logo/filter_icon.svg" alt="filter icon" className="mr-2" /> Filters</p>

                                        </div>
                                    </div>
                                    <div className="filter_wrapper mt-4">
                                        <form id="filterForm" className="">
                                            <div className="col-12 col-sm-8 offset-sm-4 padding_0">
                                                <div className="form-row">
                                                    <div className="col-4 col-sm-4 form-group fullPadding">
                                                        <select className="form-control CstmSelect filterSelect" name="week" id="week" onChange={this.onChangeweek}>
                                                            <option value="">Week</option>
                                                            {
                                                                this.state.weekNumbers.map((week: any, index: any) => {
                                                                    if (index < this.state.weekCount)
                                                                        return <option value={index + 1}>{week}</option>
                                                                })
                                                            }
                                                        </select>
                                                    </div>
                                                    <div className="col-4 col-sm-4 form-group fullPadding">
                                                        <select className="form-control CstmSelect filterSelect" name="month" id="month" onChange={this.onChangeMonth}>
                                                            <option value="">Month</option>
                                                            <option value="1">Jan</option>
                                                            <option value="2">Feb</option>
                                                            <option value="3">Mar</option>
                                                            <option value="4">Apr</option>
                                                            <option value="5">May</option>
                                                            <option value="6">Jun</option>
                                                            <option value="7">Jul</option>
                                                            <option value="8">Aug</option>
                                                            <option value="9">Sep</option>
                                                            <option value="10">Oct</option>
                                                            <option value="11">Nov</option>
                                                            <option value="12">Dec</option>
                                                        </select>
                                                    </div>
                                                    <div className="col-4 col-sm-4 form-group fullPadding">
                                                        <select className="form-control CstmSelect filterSelect" name="year" value={this.state.value} id="year" onChange={this.onChangeYear}>
                                                            <option value="">Year</option>
                                                            <option>{new Date().getFullYear() - 3}</option>
                                                            <option>{new Date().getFullYear() - 2}</option>
                                                            <option>{new Date().getFullYear() - 1}</option>
                                                            <option>{new Date().getFullYear()}</option>
                                                            <option>{new Date().getFullYear() + 1}</option>
                                                            <option>{new Date().getFullYear() + 2}</option>
                                                            <option>{new Date().getFullYear() + 3}</option>
                                                            <option>{new Date().getFullYear() + 4}</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div className="row">
                                    <span style={{ width: "100%" }}>
                                        {
                                            this.state.meetingDetails.map((details: any, index: any) => (
                                                <div className="col-12 cardWrapper" key={index}>
                                                    {
                                                        details.status === "COMPLETED" ?

                                                            <div className="cardRequest shadow_1">
                                                                <div className="cardRequest_se_time pr-0 pr-sm-4">
                                                                    <span className="p12 label label_completed">Completed</span>
                                                                    <div className="d-flex align-items-baseline mt-3">
                                                                        <div>
                                                                            <img src="assets/logo/clock_icon.svg" alt="clock" className="mr-2" />
                                                                        </div>
                                                                        <div>
                                                                            <h6><Moment format={"hh:mm A"}>{details.meeting_date}</Moment></h6>
                                                                            <p className="p12">
                                                                                {
                                                                                    moment(details.meeting_date, "YYYY-MM-DD").isSame(moment(), 'day') ?
                                                                                        (moment(details.meeting_date).format('HH:mm').valueOf() > moment().format('HH:mm').valueOf() ?
                                                                                            <span>Starts in <Moment fromNow ago={true}>{details.meeting_date}</Moment></span> :
                                                                                            <span>Meeting Ended</span>) :
                                                                                        moment(details.meeting_date, "YYYY-MM-DD").isAfter(moment()) ?
                                                                                            <span>Starts <Moment fromNow>{details.meeting_date}</Moment></span> :
                                                                                            moment(details.meeting_date, "YYYY-MM-DD").isBefore(moment()) ? "Meeting Ended" : ""
                                                                                }
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="cardRequest_se_info d-flex flex-column flex-sm-row align-items-baseline align-items-sm-center justify-content-between px-lg-4">
                                                                    <div>
                                                                        {
                                                                            sessionStorage.getItem("userType") != "DOCTOR" && (
                                                                                <div className="seekerSec">
                                                                                    <div className="seekerIcon mt-3 mr-3">
                                                                                        <img src="assets/logo/user_icon_red.svg" alt="seekerInfo" />
                                                                                    </div>
                                                                                    <div className="seekerInfo">
                                                                                        <span className="p12">Seeker Name:</span>
                                                                                        <p className="p16_bold">{details.doctor.firstname}</p>
                                                                                    </div>
                                                                                </div>
                                                                            )
                                                                        }
                                                                        {
                                                                            sessionStorage.getItem("userType") === "EXPERT" && (
                                                                                <div className="expertSec">
                                                                                    <div className="expertIcon mt-3 mr-3">
                                                                                        <img src="assets/logo/user_icon_gray.svg" alt="expertInfo" />
                                                                                    </div>
                                                                                    <div className="expertInfo">
                                                                                        <span className="p12">Organised by:</span>
                                                                                        <p className="p16_bold">{details.telecaller.firstname}</p>
                                                                                    </div>
                                                                                </div>
                                                                            )
                                                                        }
                                                                        {
                                                                            sessionStorage.getItem("userType") != "EXPERT" && (
                                                                                <div className="expertSec">
                                                                                    <div className="expertIcon mt-3 mr-3">
                                                                                        <img src="assets/logo/user_icon_gray.svg" alt="expertInfo" />
                                                                                    </div>
                                                                                    <div className="expertInfo">
                                                                                        <span className="p12">Expert Name:</span>
                                                                                        <p className="p16_bold">{details.expert.firstname}</p>
                                                                                    </div>
                                                                                </div>
                                                                            )
                                                                        }
                                                                    </div>
                                                                    <div>

                                                                        <div className="d-flex align-item-center justify-content-start justify-content-sm-end">
                                                                            <div className="ml-4">
                                                                                <img src="assets/logo/file_attachments_icon.svg" alt="file attachment" className="attachmentListToggle" onClick={() => this.handleModal(details)} />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="cardRequest_se_date pl-0 pl-sm-4">
                                                                    <div className="mb-0 mb-sm-2 mb-lg-4">
                                                                        <span className="p12"><Moment format={"dddd"}>{details.meeting_date}</Moment></span>
                                                                        <h6><Moment format={"DD MMMM, YYYY"}>{details.meeting_date}</Moment></h6>
                                                                    </div>
                                                                    {
                                                                        sessionStorage.getItem("userType") != "TELECALLER" && (

                                                                            <i className="fa fa-check" style={{ fontSize: "16px", color: "green" }}>
                                                                                <a style={{ pointerEvents: "none" }} href="#" className="btn_completed">Completed</a></i>
                                                                        )
                                                                    }
                                                                    {
                                                                         sessionStorage.getItem("userType") === "TELECALLER" && (
                                                                            <button  className="btn btn_min btn_two mb-2">follow up</button>
                                                                         )
                                                                    }

                                                                </div>
                                                            </div>

                                                            : details.status === "NOT_STARTED" ?
                                                                <span>
                                                                    <div className="cardRequest shadow_1">
                                                                        <div className="cardRequest_se_time pr-0 pr-sm-4">
                                                                            <span className="p12 label label_new">New</span>
                                                                            <div className="d-flex align-items-baseline mt-3">
                                                                                <div>
                                                                                    <img src="assets/logo/clock_icon.svg" alt="clock" className="mr-2" />
                                                                                </div>
                                                                                <div>
                                                                                    <h6><Moment format={"hh:mm A"}>{details.meeting_date}</Moment></h6>
                                                                                    <p className="p12">
                                                                                        {
                                                                                            moment(details.meeting_date, "YYYY-MM-DD").isSame(moment(), 'day') ?
                                                                                                (moment(details.meeting_date).format('HH:mm').valueOf() > moment().format('HH:mm').valueOf() ?
                                                                                                    <span>Starts in <Moment fromNow ago={true}>{details.meeting_date}</Moment></span> :
                                                                                                    <span>Meeting Ended</span>) :
                                                                                                moment(details.meeting_date, "YYYY-MM-DD").isAfter(moment()) ?
                                                                                                    <span>Starts <Moment fromNow>{details.meeting_date}</Moment></span> :
                                                                                                    moment(details.meeting_date, "YYYY-MM-DD").isBefore(moment()) ? "Meeting Ended" : ""
                                                                                        }
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div className="cardRequest_se_info d-flex flex-column flex-sm-row align-items-baseline align-items-sm-center justify-content-between px-lg-4">
                                                                            <div>
                                                                                {sessionStorage.getItem("userType") != "DOCTOR" && (
                                                                                    <div className="seekerSec">
                                                                                        <div className="seekerIcon mt-3 mr-3">
                                                                                            <img src="assets/logo/user_icon_red.svg" alt="seekerInfo" />
                                                                                        </div>
                                                                                        <div className="seekerInfo">
                                                                                            <span className="p12">Seeker Name:</span>
                                                                                            <p className="p16_bold">{details.doctor.firstname}</p>
                                                                                        </div>
                                                                                    </div>
                                                                                )}
                                                                                {sessionStorage.getItem("userType") === "EXPERT" && (
                                                                                    <div className="expertSec">
                                                                                        <div className="expertIcon mt-3 mr-3">
                                                                                            <img src="assets/logo/user_icon_gray.svg" alt="expertInfo" />
                                                                                        </div>
                                                                                        <div className="expertInfo">
                                                                                            <span className="p12">Organised by:</span>
                                                                                            <p className="p16_bold">{details.telecaller.firstname}</p>
                                                                                        </div>
                                                                                    </div>
                                                                                )
                                                                                }
                                                                                {
                                                                                    sessionStorage.getItem("userType") != "EXPERT" && (
                                                                                        <div className="expertSec">
                                                                                            <div className="expertIcon mt-3 mr-3">
                                                                                                <img src="assets/logo/user_icon_gray.svg" alt="expertInfo" />
                                                                                            </div>
                                                                                            <div className="expertInfo">
                                                                                                <span className="p12">Expert Name:</span>
                                                                                                <p className="p16_bold">{details.expert.firstname}</p>
                                                                                            </div>
                                                                                        </div>
                                                                                    )
                                                                                }
                                                                            </div>
                                                                            <div>
                                                                                <div className="d-flex align-item-center justify-content-start justify-content-sm-end">
                                                                                    <div className="uploadInpCard">
                                                                                        <input type="file" className="tc_upload upload" name="tc_upload" multiple onChange={(event) => { this.uploadFiles(event, details.meeting_id) }} />
                                                                                        <p className="p12 mr-3">Upload</p>
                                                                                        <img src="assets/logo/file_inp_icon.svg" alt="upload" />
                                                                                    </div>
                                                                                    <div className="ml-4">
                                                                                        <img src="assets/logo/file_attachments_icon.svg" alt="file attachment" className="attachmentListToggle" onClick={() => this.handleModal(details)} />
                                                                                    </div>
                                                                                </div>
                                                                                <p className="p10 linkEnableInfo mt-3">The link will enable for 10 min before the call</p>
                                                                            </div>
                                                                        </div>
                                                                        <div className="cardRequest_se_date pl-0 pl-sm-4">
                                                                            <div className="mb-0 mb-sm-2 mb-lg-4">
                                                                                <span className="p12"><Moment format={"dddd"}>{details.meeting_date}</Moment></span>
                                                                                <h6><Moment format={"DD MMMM, YYYY"}>{details.meeting_date}</Moment></h6>
                                                                            </div>
                                                                            {
                                                                                sessionStorage.getItem("userType") === "DOCTOR" && (
                                                                                    <Link to={{ pathname: "/meeting", state: details }} className="btn btn_min mb-2">Start meeting</Link>
                                                                                )
                                                                            }
                                                                            {
                                                                                sessionStorage.getItem("userType") === "EXPERT" && this.state.filterBy === 'All' && (
                                                                                    <Link to={{ pathname: "/meeting", state: details }} className="btn btn_min mb-2">Start meeting</Link>
                                                                                )
                                                                            }
                                                                            {
                                                                                sessionStorage.getItem("userType") === "EXPERT" && this.state.filterBy != 'All' && (
                                                                                    <div className="d-flex justify-content-center">
                                                                                        <button className="btn btn_sm btn_bordered mr-3 btn_reject">Reject</button>
                                                                                        {/* <button className="btn btn_sm btn_accept">Accept</button> */}
                                                                                    </div>
                                                                                )}
                                                                        </div>
                                                                    </div>
                                                                    <div className="cardReject_Input_wrapper" id={index + 1}>
                                                                        <div id="formRejectReason">
                                                                            <div className=" form-group">
                                                                                <textarea name="rejectReason" className="col-12 CstmInput CstmTextArea d-block" id="" rows={6} placeholder="Provide your reason..." onChange={this.rejectionReason}></textarea>
                                                                            </div>
                                                                            <div className="d-block  text-right">
                                                                                <button type="submit" className="btn mt-2 rejectReason_submit" onClick={() => this.rejectMeetingConfirmation()}>Submit</button>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                    <Modal show={this.state.meetingRejectionConfirmation} >
                                                                        <div className="modal-header">
                                                                            <h5 className="modal-title" id="exampleModalLabel">Confirmation</h5>
                                                                            <button type="button" className="close" onClick={() => this.handleMeetingRejectionModal()} aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div className="modal-body">
                                                                            <div className="attachmentList d-flex align-content-center justify-content-between">
                                                                                <div>
                                                                                    Are you sure to Reject the Meeting
                                                                                </div>
                                                                                <div className="d-flex">
                                                                                    <button className="btn btn_sm btn_bordered mr-3 btn_reject" onClick={() => this.rejectMeeting("no", details)}>Cancel</button>
                                                                                    <button className="btn btn_sm btn_accept" onClick={() => this.rejectMeeting("yes", details)}>Confirm</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </Modal>
                                                                </span>
                                                                : details.status === "REJECTED" ?
                                                                    <span>
                                                                        <div className="cardRequest shadow_1" id={"vrid" + index}>
                                                                            <div className="cardRequest_se_time pr-0 pr-sm-4">
                                                                                <span className="p12 label label_rejected">Rejected</span>
                                                                                <div className="d-flex align-items-baseline mt-3">
                                                                                    <div>
                                                                                        <img src="assets/logo/clock_icon.svg" alt="clock" className="mr-2" />
                                                                                    </div>
                                                                                    <div>
                                                                                        <h6><Moment format={"hh:mm A"}>{details.meeting_date}</Moment></h6>
                                                                                        <p className="p12">
                                                                                            {
                                                                                                moment(details.meeting_date, "YYYY-MM-DD").isSame(moment(), 'day') ?
                                                                                                    (moment(details.meeting_date).format('HH:mm').valueOf() > moment().format('HH:mm').valueOf() ?
                                                                                                        <span>Starts in <Moment fromNow ago={true}>{details.meeting_date}</Moment></span> :
                                                                                                        <span>Meeting Ended</span>) :
                                                                                                    moment(details.meeting_date, "YYYY-MM-DD").isAfter(moment()) ?
                                                                                                        <span>Starts <Moment fromNow>{details.meeting_date}</Moment></span> :
                                                                                                        moment(details.meeting_date, "YYYY-MM-DD").isBefore(moment()) ? "Meeting Ended" : ""
                                                                                            }
                                                                                        </p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div className="cardRequest_se_info d-flex flex-column flex-sm-row align-items-baseline align-items-sm-center justify-content-between px-lg-4">
                                                                                <div>
                                                                                    {sessionStorage.getItem("userType") != "DOCTOR" && (
                                                                                        <div className="seekerSec">
                                                                                            <div className="seekerIcon mt-3 mr-3">
                                                                                                <img src="assets/logo/user_icon_red.svg" alt="seekerInfo" />
                                                                                            </div>
                                                                                            <div className="seekerInfo">
                                                                                                <span className="p12">Seeker Name:</span>
                                                                                                <p className="p16_bold">{details.doctor.firstname}</p>
                                                                                            </div>
                                                                                        </div>
                                                                                    )}
                                                                                    {sessionStorage.getItem("userType") === "EXPERT" && (
                                                                                        <div className="expertSec">
                                                                                            <div className="expertIcon mt-3 mr-3">
                                                                                                <img src="assets/logo/user_icon_gray.svg" alt="expertInfo" />
                                                                                            </div>
                                                                                            <div className="expertInfo">
                                                                                                <span className="p12">Organised by:</span>
                                                                                                <p className="p16_bold">{details.telecaller.firstname}</p>
                                                                                            </div>
                                                                                        </div>
                                                                                    )
                                                                                    }
                                                                                    {
                                                                                        sessionStorage.getItem("userType") != "EXPERT" && (
                                                                                            <div className="expertSec">
                                                                                                <div className="expertIcon mt-3 mr-3">
                                                                                                    <img src="assets/logo/user_icon_gray.svg" alt="expertInfo" />
                                                                                                </div>
                                                                                                <div className="expertInfo">
                                                                                                    <span className="p12">Expert Name:</span>
                                                                                                    <p className="p16_bold">{details.expert.firstname}</p>
                                                                                                </div>
                                                                                            </div>
                                                                                        )
                                                                                    }

                                                                                </div>
                                                                                <div>
                                                                                    <div className="d-flex align-item-center justify-content-start justify-content-sm-end">
                                                                                        <div className="ml-4">
                                                                                            <img src="assets/logo/file_attachments_icon.svg" alt="file attachment" className="attachmentListToggle" onClick={() => this.handleModal(details)} />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div className="cardRequest_se_date pl-0 pl-sm-4">
                                                                                <div className="mb-0 mb-sm-2 mb-lg-4">
                                                                                    <span className="p12"><Moment format={"dddd"}>{details.meeting_date}</Moment></span>
                                                                                    <h6><Moment format={"DD MMMM, YYYY"}>{details.meeting_date}</Moment></h6>
                                                                                </div>
                                                                                <p className="text-uppercase view_reason_btn" onClick={() => this.showReason(index)}>
                                                                                    View Reason
                                                                                    <i className="fa fa-chevron-right ml-2" aria-hidden="true">
                                                                                    </i>
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                        <div className="cardReject_info" key={index} id={"rid" + index} style={{ display: "none" }}>
                                                                            <p className="p14 text_bold text-uppercase mb-3">Reason</p>
                                                                            <p className="p14">{details.reason}</p>
                                                                        </div>
                                                                    </span>
                                                                    : null
                                                    }
                                                </div>
                                            ))
                                        }
                                        {
                                            this.state.meetingDetails.length === 0 && (
                                                <p style={{ textAlign: "center" }}>No Meeting to Display</p>
                                            )
                                        }
                                    </span>
                                </div>
                            </div>
                            <Modal show={this.state.viewUploadedFiles} >

                                <div className="modal-header">
                                    <h5 className="modal-title" id="exampleModalLabel">Attachments</h5>
                                    <button type="button" className="close" onClick={() => this.handleModal("")} aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div className="modal-body">
                                    {this.state.files.map((file: any, index: any) =>
                                        <div className="attachmentList d-flex align-content-center justify-content-between">
                                            <div key={index} className="">
                                                <p>{file.name}</p>
                                            </div>
                                            <div className="">
                                                <a style={{ cursor: "pointer" }} onClick={() => this.downloadfile(file)}><i className="fa fa-download"></i></a>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </Modal>

                            <div className="col-12 order-1 col-md-4  order-md-2 col-lg-3 mb-5 mt-md-0">

                                <div id="calendar">
                                    <Fullcalendar
                                        plugins={[dayGridPlugin, interactionPlugin]}
                                        initialView="dayGridMonth"
                                        headerToolbar={{
                                            center: '',
                                            right: 'prev,next'
                                        }
                                        }
                                        height="auto"
                                        events={this.state.events}
                                        eventContent={renderEventContent}
                                        eventBackgroundColor="#ffffff"
                                        eventBorderColor="#ffffff"
                                        dateClick={this.onDateClicked}
                                    >
                                    </Fullcalendar>
                                </div>
                            </div>
                        </div>

                    </div>
                    <ToastContainer
                        position="top-right"
                        autoClose={5000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable={false}
                        pauseOnHover
                        theme='colored'
                    />
                </section>
                <Footer />
            </span>
        );
    }
}


// function to render calendar color code
function renderEventContent(eventInfo: any) {
    return (
        <>
            <b>{eventInfo.timeText}</b>
            <div className="calendar-marker"></div>

        </>
    )
}