import React from "react";
import "../../styles/global.css";
import "./Login.css";
import Service from "../../Service/Service";
import { RouteComponentProps } from "react-router-dom";
import Footer from "../../components/Footer/Footer";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Modal } from "react-bootstrap";
interface IProps { }

type HomeProps = IProps & RouteComponentProps;
export default class Login extends React.Component<HomeProps> {
    state: any = {
        email: '',
        password: '',
        showLoginError: false,
        concernDialogue: false,
        concentRejected: false
    }
    constructor(props: any) {
        super(props);
    }
    onValueChange = (event: any) => {
        this.setState({ [event.target.name]: event.target.value })
    };
    signIn() {
        new Service().login(this.state.email, this.state.password).then(
            loginResponse => {
                if (loginResponse.status === 200) {
                    this.setState({ showLoginError: false });
                    if (sessionStorage.getItem("userType") === "DOCTOR") {
                        this.setState({ concernDialogue: true })
                    } else {
                        this.props.history.push("/meetings");
                    }
                }
                else if (loginResponse.status === 401) {
                    window.location.href = "/" as string;
                }
                else {
                    toast.error('Something went Wrong !');
                }
            }

        ).catch(
            (error) => {
                this.setState({ showLoginError: true })
            }
        );
    }
    componentDidMount() {
        $('#LoginForm').validate({
            rules: {
                email: {
                    required: true,
                    email: true
                },
                password: {
                    required: true
                }

            },
            messages: {
                email: {
                    required: "please Enter Email",
                    email: "please Enter valid Email"
                },
                password: {
                    required: "please Enter Password"
                }
            },

            errorPlacement: function (error, element) {
                error.insertAfter($(element));

            }
        })
        $('#LoginFormSubmit').click(function (event) {
            event.preventDefault();
            var valid = $('#LoginForm').valid();
            if (valid) {
                proceed()
            }
        })
        const proceed = () => {
            this.signIn();
        }
    }
    onRejectConcent() {
        sessionStorage.clear();
        this.setState({ concernDialogue: false, concentRejected: true });
        // this.props.history.push("/")
    }
    onAcceptConcent() {
        this.setState({ concernDialogue: false });
        this.props.history.push("/meetings");
    }


    render() {
        return (
            <section className="bgWrapper">
                {
                    this.state.concentRejected === false && (
                        <div className="bgDiv">
                            <div className="outerPadding_login">
                                <div className="container">
                                    <div className="row topLftLogoWrap">
                                        <div className="col-12">
                                            <div className="topLftLogo">
                                                <a href="">
                                                    <img src="assets/logo/conversia_logo.svg" alt="conversia_logo" />
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row loginBoxWrap">
                                        <div className="col-12 mx-sm-auto col-sm-8 col-md-7 col-lg-5">
                                            <h1 className="welcomeTitle mb-5 text-center">Welcome !!</h1>
                                            <div className="LoginBox">
                                                <h2 className="mb-4 text-center">Login</h2>
                                                <p className="p14 mb-5 text-center">Welcome back! Please login to your account.</p>
                                                <form id="LoginForm">
                                                    <div className="form-group mb-5">
                                                        <input type="email" className="form-control CstmInput" name="email" placeholder="E-mail" required onChange={this.onValueChange} />
                                                    </div>
                                                    <div className="form-group">
                                                        <input type="password" className="form-control CstmInput" name="password" placeholder="Password" onChange={this.onValueChange} />
                                                    </div>
                                                    {this.state.showLoginError === true && (
                                                        <label className="error">Incorrect Username or Password</label>
                                                    )}
                                                    <div className="formBtnWrap">
                                                        <button type="submit" className="btn w-100" id="LoginFormSubmit">Login</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <ToastContainer
                                position="top-right"
                                autoClose={5000}
                                hideProgressBar={false}
                                newestOnTop={false}
                                closeOnClick
                                rtl={false}
                                pauseOnFocusLoss
                                draggable={false}
                                pauseOnHover
                                theme='colored'
                            />
                        </div>
                    )
                }
                {
                    this.state.concentRejected === true && (
                        <div className="bgDiv bgDiv_sm">
                            <div className="outerPadding_login">
                                <div className="container">
                                    <div className="row topLftLogoWrap">
                                        <div className="col-12">
                                            <div className="topLftLogo">
                                                <a href="">
                                                    <img src="assets/logo/conversia_logo.svg" alt="conversia_logo" />
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-12 mx-sm-auto col-sm-8 col-md-7 col-lg-5 text-center concentErrorDiv">
                                            <h3>SORRY!</h3>
                                            <h3 className="text_normal">You Haven't Accepted The Consent. <br />
                                                You Can't Proceed Further.</h3>
                                                <h4 style={{fontSize:"1.5rem",color:"#FFFFFF",lineHeight:"2",marginTop:"30px"}} className="text_normal">Kindly contact 18001030415 for further assistance.</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    )
                }
                <Footer />
                <Modal show={this.state.concernDialogue} backdrop="static" keyboard={false} size="lg" >

                    <div className="modal-body consentInfoDiv p-4 p-md-5">
                        <div className="text-center mb-4 mb-md-5"><h3>Consent</h3></div>
                        <div style={{ textAlign: "left" }}>
                            <div className="mb-5">
                                <h6>Initial verbal consent:</h6>
                                <p>Welcome to Conversia Helpline, you can avail KOL consultation services on “How to manage Invasive Fungal Infection”. The applicable terms and conditions will appear on the webpage. Kindly provide your acceptance thereunder.</p>
                            </div>
                            <h6>For Webpage:</h6>
                            <p>I, hereby represent, covenant and certify as follows:</p>
                            <br />
                            <ol>
                                <li> I understand and acknowledge that the service with respect to availing consultation from the Key Opinion Leaders (“KOL”) on “How to manage Invasive Fungal Infection” (the “Program”) are being provided to me as a value added service. Based on my determination to help my patients, I,  with my free will and without any coercion and/ or misrepresentation and/ or undue influence, intend to avail the service under the Program.</li>
                                <li> I shall share only non-identifiable patient information if needed for the Program, in accordance with the applicable privacy laws. </li>
                                <li> I understand that I am under no obligation to prescribe any drug marketed by Mylan Pharmaceuticals Private Limited (“Mylan”),  and will not receive any benefit from Mylan for prescribing a Mylan drug. </li>
                                <li> I understand and acknowledge that the Service is not provided in exchange for any agreement, explicit or implicit, to order, purchase, distribute, sell, prescribe, recommend or use in any way any product produced, sold or promoted by Mylan or any of its affiliates. </li>
                                <li> I acknowledge that I shall advice my patients and/ or prescribe medicines to my patients based on my professional judgement of medical necessity and that I will supervise the patient’s medical treatment accordingly. </li>
                                <li> I acknowledge that I shall remain solely responsible for all actions taken by me pursuant to the services provided under the Program. </li>
                                <li> I further acknowledge that neither Mylan nor Indegene makes any representation or assumes any responsibility for the advice and/ or information provided under the Program and that they shall not be held liable (either jointly or severally) for any error, omission and consequences – legal or otherwise, arising out of the use of any advice and or information provided under the Program.</li>
                            </ol>
                        </div>
                        <div className="text-center mt-5 d-flex align-content-center justify-content-center px-0 px-lg-5">

                            <a onClick={() => this.onRejectConcent()} className="btn btn_cancel color-white w-100 mr-4">Cancel</a>
                            <a onClick={() => this.onAcceptConcent()} className="btn w-100 color-white">Accept</a>
                        </div>

                    </div>
                </Modal>

            </section>
        );
    }
}